package com.example.tankhelper;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

public class TankOverlayService extends Service {

    public static final String ACTION_STOP = "com.example.tankhelper.ACTION_STOP";
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_DATA = "data";
    public static volatile boolean running = false;

    private static final String CHANNEL_ID = "tank_overlay_channel";
    private static final int NOTIFICATION_ID = 42;
    private static final String PREFS = "overlay_prefs";
    private static final String IMAGE_PREFIX = "tank_";

    private static final int[] SIZES_DP = {200, 260, 320, 400, 480, 560};
    private static final int DEFAULT_SIZE_INDEX = 2;

    private static final long SCAN_INTERVAL_MS = 700;
    private static final float CROP_W = 0.90f;
    private static final float CROP_H = 0.90f;

    private WindowManager windowManager;
    private View overlayView;
    private WindowManager.LayoutParams params;

    private LinearLayout headerView;
    private ImageView imageView;
    private TextView titleView;
    private TextView infoView;
    private TextView statusView;
    private TextView collapseBtn;

    private final List<Integer> imageIds = new ArrayList<Integer>();
    private final List<String> imageNames = new ArrayList<String>();
    private final List<String> imageKeys = new ArrayList<String>();
    private volatile int currentIndex = 0;
    private int sizeIndex = DEFAULT_SIZE_INDEX;
    private boolean collapsed = false;
    private boolean started = false;
    private volatile boolean destroyed = false;
    private Bitmap baseBitmap;
    private float lastTouchX, lastTouchY;

    private Handler mainHandler;
    private HandlerThread scanThread;
    private Handler scanHandler;
    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private TextRecognizer recognizer;
    private int capW = 0, capH = 0;
    private int candidate = -1, candidateCount = 0;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mainHandler = new Handler(Looper.getMainLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (started) return START_NOT_STICKY;
        started = true;

        startForegroundCompat();

        if (!Settings.canDrawOverlays(this) || intent == null || !intent.hasExtra(EXTRA_DATA)) {
            stopSelf();
            return START_NOT_STICKY;
        }

        loadImageList();
        createOverlay();
        if (overlayView == null) return START_NOT_STICKY;
        running = true;

        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent data = (Intent) intent.getParcelableExtra(EXTRA_DATA);
        startScanning(resultCode, data);
        return START_NOT_STICKY;
    }

    // ---------------- Bildirim ----------------

    private void startForegroundCompat() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW));

        Intent stopIntent = new Intent(this, TankOverlayService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 0, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle(getString(R.string.notif_title))
                .setContentText(getString(R.string.notif_text))
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel,
                        getString(R.string.notif_stop), stopPi)
                .build();

        startForeground(NOTIFICATION_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
    }

    // ---------------- Gorseller ----------------

    private void loadImageList() {
        imageIds.clear();
        imageNames.clear();
        imageKeys.clear();
        TreeMap<String, Integer> found = new TreeMap<String, Integer>();
        try {
            Class<?> drawableClass = Class.forName(R.class.getName() + "$drawable");
            for (Field f : drawableClass.getFields()) {
                if (f.getName().startsWith(IMAGE_PREFIX)) {
                    try {
                        found.put(f.getName(), f.getInt(null));
                    } catch (Exception ignored) {
                    }
                }
            }
        } catch (ClassNotFoundException ignored) {
        }
        for (Map.Entry<String, Integer> e : found.entrySet()) {
            imageNames.add(e.getKey());
            imageIds.add(e.getValue());
            imageKeys.add(makeKey(e.getKey()));
        }
    }

    private String makeKey(String resName) {
        String n = resName.substring(IMAGE_PREFIX.length());
        if (n.endsWith("_yan")) n = n.substring(0, n.length() - 4);
        else if (n.endsWith("_ust")) n = n.substring(0, n.length() - 4);
        return normalize(n);
    }

    private String normalize(String s) {
        String lower = s.toLowerCase()
                .replace("ä", "a").replace("ö", "o").replace("ü", "u").replace("ß", "ss");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lower.length(); i++) {
            char c = lower.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) sb.append(c);
        }
        return sb.toString();
    }

    private String prettyName(String resName) {
        return resName.substring(IMAGE_PREFIX.length()).replace('_', ' ').toUpperCase();
    }

    // ---------------- Ekran okuma ----------------

    private void startScanning(int resultCode, Intent data) {
        try {
            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(resultCode, data);
            if (projection == null) {
                stopSelf();
                return;
            }
            projectionCallback = new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            stopSelf();
                        }
                    });
                }
            };
            projection.registerCallback(projectionCallback, mainHandler);

            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

            scanThread = new HandlerThread("tank_scan");
            scanThread.start();
            scanHandler = new Handler(scanThread.getLooper());
            scanHandler.postDelayed(scanTask, 1500);
        } catch (Throwable t) {
            stopSelf();
        }
    }

    private final Runnable scanTask = new Runnable() {
        @Override
        public void run() {
            if (destroyed) return;
            try {
                scanOnce();
            } catch (Throwable ignored) {
            }
            if (!destroyed && scanHandler != null) {
                scanHandler.postDelayed(this, SCAN_INTERVAL_MS);
            }
        }
    };

    private void ensureCapture() {
        DisplayMetrics dm = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(dm);
        if (virtualDisplay != null && dm.widthPixels == capW && dm.heightPixels == capH) return;

        capW = dm.widthPixels;
        capH = dm.heightPixels;
        ImageReader oldReader = imageReader;
        imageReader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2);
        if (virtualDisplay == null) {
            virtualDisplay = projection.createVirtualDisplay("tank_scan", capW, capH,
                    dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(), null, null);
        } else {
            virtualDisplay.resize(capW, capH, dm.densityDpi);
            virtualDisplay.setSurface(imageReader.getSurface());
        }
        if (oldReader != null) oldReader.close();
    }

    private void scanOnce() throws Exception {
        ensureCapture();
        Image img = imageReader.acquireLatestImage();
        if (img == null) return;

        Bitmap crop;
        try {
            Image.Plane plane = img.getPlanes()[0];
            ByteBuffer buf = plane.getBuffer();
            int pixelStride = plane.getPixelStride();
            int rowPadding = plane.getRowStride() - pixelStride * capW;

            Bitmap full = Bitmap.createBitmap(capW + rowPadding / pixelStride, capH,
                    Bitmap.Config.ARGB_8888);
            full.copyPixelsFromBuffer(buf);

            View ov = overlayView;
            WindowManager.LayoutParams p = params;
            if (ov != null && p != null) {
                Canvas c = new Canvas(full);
                Paint paint = new Paint();
                paint.setColor(Color.BLACK);
                int m = 60;
                c.drawRect(p.x - m, p.y - m, p.x + ov.getWidth() + m,
                        p.y + ov.getHeight() + 2 * m, paint);
            }

            int cw = (int) (capW * CROP_W);
            int ch = (int) (capH * CROP_H);
            int cx = (capW - cw) / 2;
            int cy = (capH - ch) / 2;
            crop = Bitmap.createBitmap(full, cx, cy, cw, ch);
            full.recycle();
        } finally {
            img.close();
        }

        StringBuilder seenSb = new StringBuilder();

        // 1) Butun alani oku
        Text r0 = recognize(crop);
        seenSb.append(r0.getText().replace('\n', ' '));
        int foundIdx = findTank(r0);

        // 2) Bulunamadiysa: alani 3x2 parcaya bol, her parcayi 2 kat buyutup oku (kucuk yazilar icin)
        if (foundIdx < 0) {
            int cols = 3, rows = 2;
            int tw = crop.getWidth() / cols, th = crop.getHeight() / rows;
            int padX = tw / 6, padY = th / 6;
            for (int ry = 0; ry < rows && foundIdx < 0; ry++) {
                for (int cxi = 0; cxi < cols && foundIdx < 0; cxi++) {
                    if (destroyed) {
                        crop.recycle();
                        return;
                    }
                    int x0 = Math.max(0, cxi * tw - padX);
                    int y0 = Math.max(0, ry * th - padY);
                    int x1 = Math.min(crop.getWidth(), (cxi + 1) * tw + padX);
                    int y1 = Math.min(crop.getHeight(), (ry + 1) * th + padY);
                    Bitmap tile = Bitmap.createBitmap(crop, x0, y0, x1 - x0, y1 - y0);
                    Bitmap big = Bitmap.createScaledBitmap(tile,
                            tile.getWidth() * 2, tile.getHeight() * 2, true);
                    tile.recycle();
                    Text r = recognize(big);
                    big.recycle();
                    seenSb.append(' ').append(r.getText().replace('\n', ' '));
                    foundIdx = findTank(r);
                }
            }
        }
        crop.recycle();

        // Hata ayiklama: OCR'in ne okudugunu pencerede goster
        String raw = seenSb.toString().trim();
        if (raw.length() > 60) raw = raw.substring(0, 60);
        String shown = raw.length() == 0 ? "(yazi okunmadi)" : raw;
        if (foundIdx >= 0) shown += "  =>  " + prettyName(imageNames.get(foundIdx));
        final String seen = shown;
        final boolean hit = foundIdx >= 0;
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!destroyed && infoView != null && !collapsed) {
                    infoView.setText("Okunan: " + seen);
                }
                if (!destroyed && statusView != null) {
                    statusView.setText(hit ? "● HEDEF TANINDI" : "● TARANIYOR");
                    statusView.setTextColor(hit ? 0xFF4CFF8A : 0xFF00E5FF);
                }
            }
        });

        final int found = foundIdx;
        if (found < 0) return;

        if (found == candidate) {
            candidateCount++;
        } else {
            candidate = found;
            candidateCount = 1;
        }
        if (candidateCount >= 2 && found != currentIndex) {
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (!destroyed) showImageAnimated(found, true);
                }
            });
        }
    }

    private Text recognize(Bitmap b) throws Exception {
        return Tasks.await(recognizer.process(InputImage.fromBitmap(b, 0)), 5, TimeUnit.SECONDS);
    }

    private int findTank(Text text) {
        int best = -1;
        int bestScore = 0;
        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String l = normalize(line.getText());
                if (l.length() < 3) continue;
                for (int i = 0; i < imageKeys.size(); i++) {
                    String k = imageKeys.get(i);
                    if (k.length() < 2) continue;
                    int score = 0;
                    if (l.contains(k)) score = k.length() * 2;
                    else if (k.length() >= 5 && fuzzyContains(l, k)) score = k.length();
                    if (score > bestScore) {
                        bestScore = score;
                        best = i;
                    }
                }
            }
        }
        return best;
    }

    private boolean fuzzyContains(String line, String key) {
        for (int len = key.length() - 1; len <= key.length() + 1; len++) {
            for (int s = 0; s + len <= line.length(); s++) {
                if (levenshtein(line.substring(s, s + len), key) <= 1) return true;
            }
        }
        return false;
    }

    private int levenshtein(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[b.length()];
    }

    // ---------------- Pencere ----------------

    private void createOverlay() {
        if (overlayView != null) return;

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        params.x = prefs.getInt("x", 40);
        params.y = prefs.getInt("y", 120);
        currentIndex = prefs.getInt("index", 0);
        if (currentIndex < 0 || currentIndex >= imageIds.size()) currentIndex = 0;
        sizeIndex = prefs.getInt("size", DEFAULT_SIZE_INDEX);
        if (sizeIndex < 0 || sizeIndex >= SIZES_DP.length) sizeIndex = DEFAULT_SIZE_INDEX;

        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null);
        headerView = (LinearLayout) overlayView.findViewById(R.id.overlayHeader);
        imageView = (ImageView) overlayView.findViewById(R.id.overlayImage);
        titleView = (TextView) overlayView.findViewById(R.id.overlayTitle);
        infoView = (TextView) overlayView.findViewById(R.id.overlayInfo);
        statusView = (TextView) overlayView.findViewById(R.id.overlayStatus);
        collapseBtn = (TextView) overlayView.findViewById(R.id.overlayCollapse);

        overlayView.findViewById(R.id.overlayClose).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopSelf();
            }
        });
        overlayView.findViewById(R.id.overlayPrev).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showImageAnimated(currentIndex - 1, false);
            }
        });
        overlayView.findViewById(R.id.overlayNext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showImageAnimated(currentIndex + 1, false);
            }
        });
        overlayView.findViewById(R.id.overlayZoomIn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeSize(+1);
            }
        });
        overlayView.findViewById(R.id.overlayZoomOut).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeSize(-1);
            }
        });
        collapseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleCollapsed();
            }
        });
        // Uzun bas: bu tankin isaretini sil
        collapseBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                clearMarker();
                return true;
            }
        });

        // Gorsele uzun bas: mühimmat deposu isareti koy
        imageView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                lastTouchX = e.getX();
                lastTouchY = e.getY();
                return false;
            }
        });
        imageView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                placeMarker(lastTouchX, lastTouchY);
                return true;
            }
        });

        overlayView.setOnTouchListener(new DragTouchListener());

        applySize();
        showImage(currentIndex);

        try {
            windowManager.addView(overlayView, params);
        } catch (Exception e) {
            overlayView = null;
            stopSelf();
        }
    }

    private void changeSize(int delta) {
        int next = sizeIndex + delta;
        if (next < 0 || next >= SIZES_DP.length) return;
        sizeIndex = next;
        applySize();
        showImage(currentIndex);
        savePrefs();
    }

    private void applySize() {
        int w = dp(SIZES_DP[sizeIndex]);
        int h = w * 2 / 3;

        LinearLayout.LayoutParams hp = (LinearLayout.LayoutParams) headerView.getLayoutParams();
        hp.width = w;
        headerView.setLayoutParams(hp);

        LinearLayout.LayoutParams ip = (LinearLayout.LayoutParams) imageView.getLayoutParams();
        ip.width = w;
        ip.height = h;
        imageView.setLayoutParams(ip);

        LinearLayout.LayoutParams tp = (LinearLayout.LayoutParams) infoView.getLayoutParams();
        tp.width = w;
        infoView.setLayoutParams(tp);
    }

    /** Gecisde yumusak giris animasyonu, istege bagli titresim. */
    private void showImageAnimated(int index, boolean vibrate) {
        showImage(index);
        if (imageView != null) {
            imageView.setAlpha(0f);
            imageView.setScaleX(0.94f);
            imageView.setScaleY(0.94f);
            imageView.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start();
        }
        if (statusView != null) {
            statusView.setText(vibrate ? "● HEDEF TANINDI" : "● MANUEL");
            statusView.setTextColor(vibrate ? 0xFF4CFF8A : 0xFFFFD54F);
        }
        if (vibrate) {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null) {
                    if (Build.VERSION.SDK_INT >= 26) {
                        v.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        v.vibrate(30);
                    }
                }
            } catch (Throwable ignored) {
            }
        }
    }

    private void showImage(int index) {
        if (imageIds.isEmpty()) {
            titleView.setText("Ammo-Rack");
            infoView.setText(R.string.overlay_no_images);
            imageView.setImageResource(android.R.drawable.ic_menu_gallery);
            return;
        }
        int size = imageIds.size();
        currentIndex = ((index % size) + size) % size;

        titleView.setText(prettyName(imageNames.get(currentIndex)));
        infoView.setText((currentIndex + 1) + " / " + size + "   "
                + getString(R.string.overlay_hint));

        int w = dp(SIZES_DP[sizeIndex]);
        baseBitmap = decodeSampled(imageIds.get(currentIndex), w, w * 2 / 3);
        redrawImage();
        savePrefs();
    }

    /** Gorseli ve (varsa) kaydedilmis isareti cizer. */
    private void redrawImage() {
        if (baseBitmap == null) {
            imageView.setImageResource(android.R.drawable.ic_menu_report_image);
            return;
        }
        float[] m = loadMarker();
        if (m == null) {
            imageView.setImageBitmap(baseBitmap);
            return;
        }
        Bitmap copy = baseBitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas c = new Canvas(copy);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(Color.RED);
        p.setStrokeWidth(Math.max(3f, copy.getWidth() * 0.008f));
        float cx = m[0] * copy.getWidth();
        float cy = m[1] * copy.getHeight();
        float r = copy.getWidth() * 0.035f;
        c.drawCircle(cx, cy, r, p);
        c.drawLine(cx - r * 1.8f, cy, cx + r * 1.8f, cy, p);
        c.drawLine(cx, cy - r * 1.8f, cx, cy + r * 1.8f, p);
        imageView.setImageBitmap(copy);
    }

    private void placeMarker(float touchX, float touchY) {
        if (baseBitmap == null) return;
        float[] v = new float[9];
        imageView.getImageMatrix().getValues(v);
        float scale = v[android.graphics.Matrix.MSCALE_X];
        if (scale <= 0f) return;
        float fx = ((touchX - v[android.graphics.Matrix.MTRANS_X]) / scale) / baseBitmap.getWidth();
        float fy = ((touchY - v[android.graphics.Matrix.MTRANS_Y]) / scale) / baseBitmap.getHeight();
        if (fx < 0f || fx > 1f || fy < 0f || fy > 1f) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putFloat("mx_" + imageNames.get(currentIndex), fx)
                .putFloat("my_" + imageNames.get(currentIndex), fy)
                .apply();
        redrawImage();
    }

    private void clearMarker() {
        if (imageNames.isEmpty()) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .remove("mx_" + imageNames.get(currentIndex))
                .remove("my_" + imageNames.get(currentIndex))
                .apply();
        redrawImage();
    }

    private float[] loadMarker() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String n = imageNames.get(currentIndex);
        if (!p.contains("mx_" + n)) return null;
        return new float[]{p.getFloat("mx_" + n, 0f), p.getFloat("my_" + n, 0f)};
    }

    private void toggleCollapsed() {
        collapsed = !collapsed;
        int vis = collapsed ? View.GONE : View.VISIBLE;
        imageView.setVisibility(vis);
        infoView.setVisibility(vis);
        collapseBtn.setText(collapsed ? "▸" : "▾");
    }

    // ---------------- Yardimci ----------------

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Bitmap decodeSampled(int resId, int reqW, int reqH) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            o.inScaled = false;
            BitmapFactory.decodeResource(getResources(), resId, o);

            int sample = 1;
            while ((o.outWidth / (sample * 2)) >= reqW && (o.outHeight / (sample * 2)) >= reqH) {
                sample *= 2;
            }
            o.inJustDecodeBounds = false;
            o.inSampleSize = sample;
            return BitmapFactory.decodeResource(getResources(), resId, o);
        } catch (Throwable t) {
            return null;
        }
    }

    private void savePrefs() {
        if (params == null) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("x", params.x)
                .putInt("y", params.y)
                .putInt("index", currentIndex)
                .putInt("size", sizeIndex)
                .apply();
    }

    private class DragTouchListener implements View.OnTouchListener {
        private int startX, startY;
        private float touchX, touchY;

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX = params.x;
                    startY = params.y;
                    touchX = event.getRawX();
                    touchY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = startX + (int) (event.getRawX() - touchX);
                    params.y = startY + (int) (event.getRawY() - touchY);
                    if (overlayView != null) {
                        try {
                            windowManager.updateViewLayout(overlayView, params);
                        } catch (Exception ignored) {
                        }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    savePrefs();
                    return true;
            }
            return false;
        }
    }

    // ---------------- Kapanis ----------------

    @Override
    public void onDestroy() {
        destroyed = true;
        running = false;
        savePrefs();

        if (scanHandler != null) scanHandler.removeCallbacksAndMessages(null);
        if (scanThread != null) scanThread.quitSafely();
        try {
            if (virtualDisplay != null) virtualDisplay.release();
        } catch (Throwable ignored) {
        }
        try {
            if (imageReader != null) imageReader.close();
        } catch (Throwable ignored) {
        }
        try {
            if (projection != null) {
                if (projectionCallback != null) projection.unregisterCallback(projectionCallback);
                projection.stop();
            }
        } catch (Throwable ignored) {
        }
        try {
            if (recognizer != null) recognizer.close();
        } catch (Throwable ignored) {
        }
        if (overlayView != null) {
            try {
                windowManager.removeView(overlayView);
            } catch (Exception ignored) {
            }
            overlayView = null;
        }
        if (imageView != null) imageView.setImageDrawable(null);
        stopForeground(true);
        super.onDestroy();
    }
}
