package com.example.tankhelper;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Cevrimdisi egitim modu: statik tank gorselinde mühimmat deposunun yerini tahmin et.
 * Oyun ekranini OKUMAZ, hicbir seye yer paylasmaz. Yalnizca uygulamanin icindeki gorselleri kullanir.
 * Dogru yer = overlay'de gorsele uzun basarak senin koydugun isaret.
 */
public class QuizActivity extends Activity {

    private static final String PREFS = "overlay_prefs";
    private static final String IMAGE_PREFIX = "tank_";

    // Reticle durum makinesi
    private enum State { WAITING, GREEN, ORANGE, RED }

    private static final int C_GREEN = 0xFF4CFF8A;
    private static final int C_ORANGE = 0xFFFFA726;
    private static final int C_RED = 0xFFEF5350;
    private static final int C_IDLE = 0xFFFFFFFF;

    // Mesafe esikleri (gorsel genisligine oranla)
    private static final float GREEN_DIST = 0.06f;
    private static final float ORANGE_DIST = 0.13f;

    private final List<String> names = new ArrayList<String>();
    private final List<Integer> ids = new ArrayList<Integer>();
    private final List<float[]> markers = new ArrayList<float[]>();
    private final List<Integer> order = new ArrayList<Integer>();

    private int pos = -1;
    private int score = 0, tries = 0;
    private State state = State.WAITING;
    private Bitmap current;

    private QuizView quizView;
    private TextView titleView, scoreView, statusView;
    private Button nextBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        loadData();
        if (order.isEmpty()) {
            titleView.setText("Egitim modu");
            statusView.setText("Henuz isaret yok. Once overlay'de bir gorsele uzun basip "
                    + "mühimmat deposunu isaretle, sonra buraya don.");
            nextBtn.setEnabled(false);
            return;
        }
        nextRound();
    }

    // ---------------- Arayuz ----------------

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0B0F18);
        root.setPadding(dp(12), dp(12), dp(12), dp(12));

        titleView = new TextView(this);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(18);
        titleView.setGravity(Gravity.CENTER);
        root.addView(titleView);

        scoreView = new TextView(this);
        scoreView.setTextColor(0xFFB0B8C8);
        scoreView.setGravity(Gravity.CENTER);
        scoreView.setText("Skor: 0 / 0");
        root.addView(scoreView);

        quizView = new QuizView(this);
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        qp.topMargin = dp(8);
        qp.bottomMargin = dp(8);
        root.addView(quizView, qp);

        statusView = new TextView(this);
        statusView.setTextColor(Color.WHITE);
        statusView.setTextSize(16);
        statusView.setGravity(Gravity.CENTER);
        root.addView(statusView);

        nextBtn = new Button(this);
        nextBtn.setText("Sonraki");
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextRound();
            }
        });
        root.addView(nextBtn);

        setContentView(root);

        quizView.setListener(new QuizView.Listener() {
            @Override
            public void onGuess(float fx, float fy) {
                handleGuess(fx, fy);
            }
        });
    }

    // ---------------- Veri ----------------

    /** Yalnizca isareti olan tanklari yukler (isaret = dogru cevap). */
    private void loadData() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        try {
            Class<?> dc = Class.forName(R.class.getName() + "$drawable");
            for (Field f : dc.getFields()) {
                String n = f.getName();
                if (!n.startsWith(IMAGE_PREFIX)) continue;
                if (!p.contains("mx_" + n)) continue;
                try {
                    ids.add(f.getInt(null));
                    names.add(n);
                    markers.add(new float[]{p.getFloat("mx_" + n, 0f), p.getFloat("my_" + n, 0f)});
                } catch (Exception ignored) {
                }
            }
        } catch (ClassNotFoundException ignored) {
        }
        for (int i = 0; i < ids.size(); i++) order.add(i);
        Collections.shuffle(order);
    }

    // ---------------- Oyun akisi ----------------

    private void nextRound() {
        pos = (pos + 1) % order.size();
        int idx = order.get(pos);
        if (current != null) current.recycle();
        current = decodeSampled(ids.get(idx), 1200, 800);
        titleView.setText(prettyName(names.get(idx)));
        state = State.WAITING;
        quizView.setImage(current);
        quizView.clearGuess();
        statusView.setTextColor(C_IDLE);
        statusView.setText("Mühimmat deposu nerede? Dokun.");
        nextBtn.setText("Atla");
    }

    private void handleGuess(float fx, float fy) {
        if (state != State.WAITING || current == null) return;
        float[] m = markers.get(order.get(pos));
        float aspect = (float) current.getHeight() / (float) current.getWidth();
        float dx = fx - m[0];
        float dy = (fy - m[1]) * aspect;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);

        // Durum makinesi: WAITING -> GREEN | ORANGE | RED
        if (dist <= GREEN_DIST) state = State.GREEN;
        else if (dist <= ORANGE_DIST) state = State.ORANGE;
        else state = State.RED;

        tries++;
        if (state == State.GREEN) score++;
        scoreView.setText("Skor: " + score + " / " + tries);

        int color;
        String msg;
        switch (state) {
            case GREEN:
                color = C_GREEN;
                msg = "Dogru! Tam isabet.";
                break;
            case ORANGE:
                color = C_ORANGE;
                msg = "Yakin, ama tam degil.";
                break;
            default:
                color = C_RED;
                msg = "Yanlis. Beyaz halka dogru yeri gosteriyor.";
                break;
        }
        statusView.setTextColor(color);
        statusView.setText(msg);
        quizView.showGuess(fx, fy, color, m[0], m[1]);
        nextBtn.setText("Sonraki");
    }

    // ---------------- Yardimci ----------------

    private String prettyName(String resName) {
        return resName.substring(IMAGE_PREFIX.length()).replace('_', ' ').toUpperCase();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Bitmap decodeSampled(int resId, int reqW, int reqH) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            o.inScaled = false;
            BitmapFactory.decodeResource(getResources(), resId, o);
            int sample = 1;
            while ((o.outWidth / (sample * 2)) >= reqW && (o.outHeight / (sample * 2)) >= reqH) {
                sample *= 2;
            }
            o.inJustDecodeBounds = false;
            o.inSampleSize = sample;
            return BitmapFactory.decodeResource(getResources(), resId, o);
        } catch (Throwable t) {
            return null;
        }
    }

    @Override
    protected void onDestroy() {
        if (current != null) current.recycle();
        current = null;
        super.onDestroy();
    }

    // ---------------- Ozel gorunum ----------------

    private static class QuizView extends View {

        interface Listener {
            void onGuess(float fx, float fy);
        }

        private Bitmap bmp;
        private final RectF dst = new RectF();
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Listener listener;
        private boolean hasGuess = false;
        private float gx, gy, rx, ry;
        private int color = Color.WHITE;

        QuizView(android.content.Context c) {
            super(c);
        }

        void setListener(Listener l) {
            listener = l;
        }

        void setImage(Bitmap b) {
            bmp = b;
            invalidate();
        }

        void clearGuess() {
            hasGuess = false;
            invalidate();
        }

        void showGuess(float fx, float fy, int c, float realX, float realY) {
            gx = fx;
            gy = fy;
            rx = realX;
            ry = realY;
            color = c;
            hasGuess = true;
            invalidate();
        }

        private void computeRect() {
            if (bmp == null) return;
            float s = Math.min((float) getWidth() / bmp.getWidth(),
                    (float) getHeight() / bmp.getHeight());
            float w = bmp.getWidth() * s, h = bmp.getHeight() * s;
            float l = (getWidth() - w) / 2f, t = (getHeight() - h) / 2f;
            dst.set(l, t, l + w, t + h);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (bmp == null) return;
            computeRect();
            canvas.drawBitmap(bmp, null, dst, null);
            if (!hasGuess) return;

            float r = dst.width() * 0.035f;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(3f, dst.width() * 0.007f));

            // Dogru yer: beyaz halka
            paint.setColor(Color.WHITE);
            float cx = dst.left + rx * dst.width();
            float cy = dst.top + ry * dst.height();
            canvas.drawCircle(cx, cy, r, paint);

            // Tahmin: durum rengiyle reticle
            paint.setColor(color);
            float px = dst.left + gx * dst.width();
            float py = dst.top + gy * dst.height();
            canvas.drawCircle(px, py, r, paint);
            canvas.drawLine(px - r * 1.8f, py, px + r * 1.8f, py, paint);
            canvas.drawLine(px, py - r * 1.8f, px, py + r * 1.8f, paint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (bmp == null) return false;
            if (e.getAction() == MotionEvent.ACTION_DOWN) return true;
            if (e.getAction() == MotionEvent.ACTION_UP && listener != null) {
                computeRect();
                float fx = (e.getX() - dst.left) / dst.width();
                float fy = (e.getY() - dst.top) / dst.height();
                if (fx >= 0f && fx <= 1f && fy >= 0f && fy <= 1f) {
                    listener.onGuess(fx, fy);
                }
                return true;
            }
            return false;
        }
    }
}
