package com.example.tankhelper;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_OVERLAY = 1001;
    private static final int REQ_NOTIFICATIONS = 1002;
    private static final int REQ_CAPTURE = 1003;
    private static final String NOTIF_PERMISSION = "android.permission.POST_NOTIFICATIONS";

    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        statusText = (TextView) findViewById(R.id.statusText);
        Button btnStart = (Button) findViewById(R.id.btnStart);
        Button btnStop = (Button) findViewById(R.id.btnStop);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hasOverlayPermission()) requestCapture();
                else requestOverlayPermission();
            }
        });

        findViewById(R.id.btnQuiz).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, QuizActivity.class));
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(new Intent(MainActivity.this, TankOverlayService.class));
                statusText.setText(R.string.status_stopped);
            }
        });

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(NOTIF_PERMISSION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{NOTIF_PERMISSION}, REQ_NOTIFICATIONS);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        statusText.setText(TankOverlayService.running
                ? R.string.status_running : R.string.status_stopped);
    }

    private boolean hasOverlayPermission() {
        return Settings.canDrawOverlays(this);
    }

    private void requestOverlayPermission() {
        Toast.makeText(this, R.string.toast_need_permission, Toast.LENGTH_LONG).show();
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        try {
            startActivityForResult(intent, REQ_OVERLAY);
        } catch (Exception e) {
            Toast.makeText(this, R.string.toast_enable_manually, Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void requestCapture() {
        MediaProjectionManager mpm =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY) {
            if (hasOverlayPermission()) requestCapture();
            else Toast.makeText(this, R.string.toast_denied, Toast.LENGTH_LONG).show();
        } else if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) startOverlay(resultCode, data);
            else Toast.makeText(this, R.string.toast_capture_denied, Toast.LENGTH_LONG).show();
        }
    }

    private void startOverlay(int resultCode, Intent data) {
        Intent intent = new Intent(this, TankOverlayService.class);
        intent.putExtra(TankOverlayService.EXTRA_RESULT_CODE, resultCode);
        intent.putExtra(TankOverlayService.EXTRA_DATA, data);
        startForegroundService(intent);
        statusText.setText(R.string.status_running);
        Toast.makeText(this, R.string.toast_started, Toast.LENGTH_SHORT).show();
    }
}
